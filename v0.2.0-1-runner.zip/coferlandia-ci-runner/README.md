# Coferlandia CI Runner

Runner self-hosted de GitHub Actions aislado en Docker para compartir la VM de Coferlandia sin compartir el daemon Docker del stack productivo.

## Objetivos

- Ejecutar CI en infraestructura propia sin consumir minutos de runners hospedados por GitHub.
- Limitar CPU, RAM, PIDs y almacenamiento del stack de CI.
- Conservar cachés útiles entre reintentos para evitar reconstrucciones completas.
- Eliminar contenedores, redes y volúmenes temporales después de cada job.
- Ejecutar limpieza diaria y limpieza agresiva por umbrales de disco.
- Supervisar runner, Docker interno, disco y estado remoto de GitHub.
- Enviar alertas y recuperaciones mediante Telegram.
- No publicar puertos nuevos en Internet.

## Arquitectura

```text
GitHub Actions
     │ HTTPS saliente 443
     ▼
VM Coferlandia
├── stack productivo existente
└── coferlandia-ci-runner
    ├── runner             CPU/RAM/PIDs limitados
    ├── docker-ci (DinD)   daemon exclusivo, TLS interno, disco limitado
    ├── /srv/coferlandia-ci filesystem ext4 de tamaño fijo
    └── systemd
        ├── watchdog cada 5 minutos
        └── cleanup diario
```

El runner **no monta `/var/run/docker.sock` del host**. Los workflows sólo controlan `docker-ci`, un daemon Docker exclusivo dentro del stack de CI.

## Puertos

No hay ninguna sección `ports:` en `compose.yml`.

- No se abre ningún puerto entrante adicional en la VM.
- GitHub no inicia conexiones hacia el servidor.
- El runner abre conexiones HTTPS salientes por TCP 443.
- El puerto TLS 2376 de Docker-in-Docker sólo existe en la red Docker interna `coferlandia-ci-network`.

Consulte [docs/NETWORKING.md](docs/NETWORKING.md).

## Instalación rápida

Primero consulte [Conexión a la VM y carga del proyecto](docs/VM_DEPLOYMENT.md). Luego, dentro de la VM:

```bash
unzip coferlandia-ci-runner-0.2.0.zip
cd coferlandia-ci-runner
./scripts/host-survey.sh before
cp .env.example .env
nano .env

sudo ./scripts/install-host.sh
./scripts/check-prerequisites.sh
./scripts/register-runner.sh
sudo ./scripts/install-systemd.sh
./scripts/verify-installation.sh
./scripts/host-survey.sh after-idle
```

Después copie `examples/workflows/runner-smoke-test.yml` a un repositorio autorizado como `.github/workflows/runner-smoke-test.yml` y ejecútelo manualmente.

La guía completa está en [docs/INSTALLATION.md](docs/INSTALLATION.md).

## Operación habitual

```bash
./scripts/status.sh
./scripts/start.sh
./scripts/stop.sh
./scripts/restart.sh
docker compose logs --tail=200 -f
sudo ./scripts/cleanup.sh
```

También hay objetivos equivalentes en `Makefile`.

## Retención y rendimiento

Después de cada job se eliminan:

- contenedores de prueba;
- redes temporales;
- volúmenes temporales.

Se conservan con límites:

- checkout del repositorio;
- imágenes Docker recientes;
- build cache;
- cachés NuGet, npm y pip;
- tool cache del runner.

Esto permite que una corrección seguida de un nuevo commit reutilice dependencias y capas de compilación. La limpieza diaria reduce caché antigua, y el filesystem limitado evita que CI llene el disco principal de la VM.

## Documentación

- [Conexión SSH, carga del ZIP y creación del proyecto](docs/VM_DEPLOYMENT.md)
- [Instalación](docs/INSTALLATION.md)
- [Relevamiento antes/después](docs/HOST_SURVEY.md)
- [Conexión con GitHub](docs/GITHUB_CONFIGURATION.md)
- [Redes y puertos](docs/NETWORKING.md)
- [Monitoreo y Telegram](docs/MONITORING.md)
- [Mantenimiento y limpieza](docs/MAINTENANCE.md)
- [Seguridad](docs/SECURITY.md)
- [Uso en workflows](docs/WORKFLOW_USAGE.md)
- [Resolución de problemas](docs/TROUBLESHOOTING.md)

## Fuentes oficiales

- GitHub: self-hosted runners: https://docs.github.com/en/actions/reference/runners/self-hosted-runners
- GitHub: agregar runners: https://docs.github.com/en/actions/how-tos/manage-runners/self-hosted-runners/add-runners
- GitHub: monitoreo y `_diag`: https://docs.github.com/actions/how-tos/managing-self-hosted-runners/monitoring-and-troubleshooting-self-hosted-runners
- Docker: resource constraints: https://docs.docker.com/engine/containers/resource_constraints/
- Docker Compose services: https://docs.docker.com/reference/compose-file/services/
- Telegram Bot API: https://core.telegram.org/bots/api
