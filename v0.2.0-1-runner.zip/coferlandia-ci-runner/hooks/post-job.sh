#!/usr/bin/env bash
# Limpieza liviana: conserva imágenes y caché de compilación para acelerar el
# siguiente intento, pero elimina ambientes de prueba descartables.
set -uo pipefail

log() {
  printf '[post-job] %s\n' "$*"
}

if ! docker info >/dev/null 2>&1; then
  log "ADVERTENCIA: Docker CI no responde; el watchdog realizará el diagnóstico"
  exit 0
fi

log "Eliminando contenedores, redes y volúmenes temporales"
docker ps -aq | xargs -r docker rm -f >/dev/null 2>&1 || true
docker network prune -f >/dev/null 2>&1 || true
docker volume prune -f >/dev/null 2>&1 || true

log "Se conservan imágenes, dependencias y build cache reutilizables"
docker system df || true
exit 0
