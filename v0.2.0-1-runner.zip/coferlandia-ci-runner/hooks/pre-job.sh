#!/usr/bin/env bash
# Hook defensivo previo a cada job. El daemon Docker es exclusivo de CI y se
# ejecuta un solo job a la vez, por lo que puede limpiar residuos de ejecuciones
# anteriores sin afectar al Docker principal de la VM.
set -uo pipefail

log() {
  printf '[pre-job] %s\n' "$*"
}

if ! docker info >/dev/null 2>&1; then
  log "ERROR: Docker CI no responde"
  exit 1
fi

log "Eliminando contenedores, redes y volúmenes huérfanos de jobs anteriores"
docker ps -aq | xargs -r docker rm -f >/dev/null 2>&1 || true
docker network prune -f >/dev/null 2>&1 || true
docker volume prune -f >/dev/null 2>&1 || true

log "Estado de almacenamiento Docker antes del job"
docker system df || true
exit 0
