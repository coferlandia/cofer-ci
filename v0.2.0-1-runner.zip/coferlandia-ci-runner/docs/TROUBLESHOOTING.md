# Resolución de problemas

## Runner offline en GitHub

```bash
./scripts/status.sh
docker compose logs runner --tail=300
sudo ls -lah /srv/coferlandia-ci/runner/_diag
```

Compruebe HTTPS saliente:

```bash
docker compose exec runner curl -I https://api.github.com
```

## Docker CI unhealthy

```bash
docker compose logs docker-ci --tail=300
docker compose exec docker-ci docker info
df -h /srv/coferlandia-ci
```

Causas frecuentes:

- filesystem lleno;
- certificados TLS incompletos;
- daemon bloqueado;
- límite de memoria alcanzado.

Reinicio controlado:

```bash
docker compose restart docker-ci
sleep 15
docker compose restart runner
```

## No space left on device

```bash
sudo ./scripts/cleanup.sh
df -h /srv/coferlandia-ci
du -xh --max-depth=2 /srv/coferlandia-ci | sort -h
```

Si el runner fue pausado por emergencia, se reinicia al bajar del umbral de recuperación. También puede hacerlo manualmente después de liberar espacio:

```bash
rm -f /srv/coferlandia-ci/.runner-paused-disk
docker compose up -d runner
```

## Job queda queued

Compruebe:

- que el runner esté `online` e `idle`;
- que `runs-on` incluya una etiqueta existente;
- que el runner group permita ese repositorio;
- que otro job no esté ocupando el único runner.

## Error con actions/checkout

Asegure que el runner esté actualizado y use:

```yaml
- uses: actions/checkout@v6
  with:
    clean: true
```

## Error de permisos en workspace o cache

```bash
sudo chown -R 1001:123   /srv/coferlandia-ci/runner   /srv/coferlandia-ci/work   /srv/coferlandia-ci/cache
```

## El watchdog no envía Telegram

```bash
sudo ./scripts/test-telegram.sh
sudo journalctl -u coferlandia-ci-watchdog.service -n 100
sudo stat /etc/coferlandia-ci-watchdog.env
```

Compruebe que el bot recibió previamente `/start` y que `TELEGRAM_CHAT_ID` sea correcto.

## Obtener logs de diagnóstico extendidos

En GitHub, configure temporalmente la variable o secret:

```text
ACTIONS_RUNNER_DEBUG=true
```

Vuelva a ejecutar el job y descargue los logs de la ejecución. Quite la variable cuando termine porque aumenta el volumen de logs.

## Reset completo conservando el proyecto

Use sólo si el registro local está corrupto:

1. elimine el runner desde GitHub;
2. detenga el stack;
3. elimine únicamente `/srv/coferlandia-ci/runner`;
4. recree permisos;
5. registre nuevamente.

No es necesario eliminar caché, Docker CI o workspace salvo que también estén dañados.
