# Seguridad

## Modelo de confianza

Un workflow puede ejecutar comandos arbitrarios. Aunque este proyecto aísla el daemon Docker de CI del daemon del host, Docker-in-Docker se ejecuta con `privileged: true` y comparte el kernel de la VM. Esto reduce mucho el riesgo operativo sobre los contenedores productivos, pero no convierte a la VM en una frontera segura frente a código hostil.

Use este runner únicamente para repositorios privados y código confiable administrado por Coferlandia.

## Controles implementados

- No se monta `/var/run/docker.sock` del host.
- Docker CI usa un daemon separado.
- Comunicación runner↔Docker CI mediante TLS interno.
- Ningún puerto publicado al host.
- CPU, RAM y PIDs limitados.
- Filesystem de CI de tamaño fijo.
- Runner sin privilegios y con `no-new-privileges`.
- Secrets de monitoreo sólo en `/etc`, no en el runner.
- Logs con rotación.
- Limpieza y watchdog externos al runner.

## Controles recomendados en GitHub

- Runner group restringido a repositorios seleccionados.
- No ejecutar PR de forks públicos automáticamente.
- `permissions: contents: read` por defecto.
- Secrets productivos sólo en environments protegidos.
- Aprobación manual para deployments.
- Branch protection y revisión de cambios en `.github/workflows`.
- Separar workflow de test del workflow de deployment.

## Secrets

No coloque en `.env`:

- PAT permanentes;
- token del bot Telegram;
- secretos productivos;
- claves SSH personales.

Ubicación de monitoreo:

```text
/etc/coferlandia-ci-watchdog.env
```

Permisos:

```bash
sudo chmod 600 /etc/coferlandia-ci-watchdog.env
```

## Imágenes y acciones de terceros

Fije versiones mayores confiables o, para mayor seguridad de cadena de suministro, hashes completos. Revise acciones externas antes de utilizarlas.

## Producción en la misma VM

Los límites de recursos disminuyen el impacto de builds pesados, pero no eliminan toda contención de CPU, memoria e I/O. Observe durante las primeras semanas:

```bash
docker stats
iostat -xz 1
vmstat 1
```

Si CI afecta servicios productivos, reduzca `DIND_CPUS`/`DIND_MEMORY`, disminuya concurrencia o migre el runner a una VM dedicada.
