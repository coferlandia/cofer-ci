# Redes, firewall y publicación de puertos

## No publicar puertos

Este proyecto no requiere ningún puerto entrante nuevo.

`compose.yml` no contiene `ports:`. El puerto 2376 declarado con `expose` es visible solamente entre los contenedores de la red Docker interna.

| Flujo | Puerto | Exposición |
|---|---:|---|
| Administrador → VM | TCP 22 | SSH existente; no lo crea este proyecto |
| Runner → GitHub | TCP 443 | Saliente |
| Runner → registries y acciones | TCP 443 | Saliente |
| Watchdog → Telegram | TCP 443 | Saliente |
| Runner → Docker CI | TCP 2376 | Sólo red Docker interna, con TLS |
| Internet → runner | Ninguno | No permitido ni necesario |

No configure reglas nuevas en OCI Security Lists, Network Security Groups, UFW ni router doméstico para 2376.

## Por qué GitHub no necesita entrar a la VM

El listener del runner mantiene una conexión saliente hacia GitHub para recibir jobs. Por eso basta permitir HTTPS saliente por 443.

## Destinos salientes

Como mínimo deben funcionar:

- `github.com`;
- `api.github.com`;
- dominios de Actions y `githubusercontent.com` indicados por GitHub;
- `ghcr.io` para la imagen oficial del runner;
- Docker Hub u otros registries usados por los proyectos;
- `api.telegram.org` para alertas;
- repositorios de paquetes usados por los workflows.

La lista exacta puede cambiar. Si la VM no aplica un firewall saliente restrictivo, no necesita mantener una allowlist. Si lo aplica, use nombres DNS y consulte la lista oficial de GitHub en lugar de fijar IPs.

## UFW

Una política normal puede conservar únicamente SSH entrante:

```bash
sudo ufw status verbose
```

No ejecute:

```bash
sudo ufw allow 2376
```

El puerto de Docker CI no debe estar publicado.

## Verificaciones

Desde el host:

```bash
curl -I https://github.com
curl -I https://api.github.com
curl -I https://api.telegram.org
```

Desde el runner:

```bash
docker compose exec runner curl -I https://api.github.com
```

Compruebe que no existe publicación accidental:

```bash
docker compose ps
sudo ss -lntp
```

La columna `PORTS` no debe mostrar `0.0.0.0:2376` ni `[::]:2376`.
