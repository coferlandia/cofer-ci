# Mantenimiento y política de limpieza

## Qué se conserva entre jobs

- checkout de repositorios;
- caché de herramientas instalada por `setup-*`;
- paquetes NuGet, npm y pip;
- imágenes Docker recientes;
- build cache de Docker y Buildx.

Esto acelera el ciclo:

```text
commit → CI falla → corrección → nuevo commit → CI vuelve a correr
```

El segundo job puede reutilizar dependencias y capas no modificadas.

## Qué se elimina después de cada job

Los hooks `pre-job.sh` y `post-job.sh` eliminan en el Docker exclusivo de CI:

- contenedores;
- redes no usadas;
- volúmenes no usados.

No ejecutan `docker system prune -a` y no eliminan todas las imágenes después de cada job.

Los workflows también deberían cerrar su ambiente con:

```yaml
- name: Cerrar ambiente
  if: always()
  run: docker compose down --volumes --remove-orphans
```

## Limpieza diaria

El timer ejecuta:

```bash
sudo ./scripts/cleanup.sh
```

La rutina:

1. elimina recursos no utilizados;
2. descarta imágenes antiguas;
3. limita caché de builder/buildx;
4. elimina archivos de package cache sin acceso reciente;
5. aumenta la agresividad si el disco supera el umbral.

No elimina workspaces mientras detecta un `Runner.Worker` activo.

## Umbrales

Configuración predeterminada:

```env
DISK_WARN_PERCENT=75
DISK_AGGRESSIVE_PERCENT=82
DISK_EMERGENCY_PERCENT=90
DISK_RECOVERY_PERCENT=70
```

- 75%: alerta.
- 82%: reduce cachés y elimina workspaces antiguos, sólo si no hay job activo.
- 90%: detiene el runner si no hay job activo para proteger la VM.
- 70%: reinicia automáticamente un runner pausado por presión de disco.

El filesystem limitado sigue siendo la defensa final. El watchdog también controla el porcentaje usado del filesystem raíz de la VM, porque el archivo sparse reside allí.

## Diagnóstico de espacio

```bash
df -h /srv/coferlandia-ci
du -xh --max-depth=2 /srv/coferlandia-ci | sort -h
docker compose exec docker-ci docker system df -v
```

## Actualizaciones

Cuando no haya jobs activos:

```bash
./scripts/update.sh
```

El script:

- actualiza Docker-in-Docker;
- vuelve a construir desde la imagen oficial del runner;
- conserva registro, workspace y cachés;
- reinicia los servicios.

Revise mensualmente:

```bash
./scripts/status.sh
docker compose images
systemctl list-timers 'coferlandia-ci-*' --all
```

## Backup

No se necesita backup del workspace ni de las cachés. El único estado importante es el registro local del runner, que también puede recrearse.

Antes de una intervención importante puede guardar sólo la configuración:

```bash
sudo tar czf /root/coferlandia-ci-runner-config.tgz   /srv/coferlandia-ci/runner/.runner   /srv/coferlandia-ci/runner/.credentials   /srv/coferlandia-ci/runner/.credentials_rsaparams
```

Ese archivo contiene credenciales sensibles. Manténgalo bajo root y elimínelo cuando termine.

## Cambio de tamaño del filesystem

Para ampliar el archivo de 30 GB a 40 GB:

```bash
sudo systemctl stop coferlandia-ci-watchdog.timer coferlandia-ci-cleanup.timer
docker compose stop
sudo umount /srv/coferlandia-ci
sudo truncate -s 40G /var/lib/coferlandia-ci.img
sudo e2fsck -f /var/lib/coferlandia-ci.img
sudo resize2fs /var/lib/coferlandia-ci.img
sudo mount /srv/coferlandia-ci
docker compose up -d
sudo systemctl start coferlandia-ci-watchdog.timer coferlandia-ci-cleanup.timer
```

No reduzca el archivo sin un procedimiento específico de reducción de filesystem ext4.
