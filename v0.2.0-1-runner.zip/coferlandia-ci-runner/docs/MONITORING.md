# Monitoreo y alertas

## Capas de diagnóstico

1. GitHub muestra el runner como `Idle`, `Active` u `Offline` y conserva logs de cada job.
2. Docker healthchecks validan el listener y el daemon Docker CI.
3. `scripts/status.sh` muestra estado, recursos, disco y cachés.
4. systemd ejecuta `scripts/watchdog.sh` cada cinco minutos.
5. Telegram recibe alertas deduplicadas y mensajes de recuperación.

GitHub puede diagnosticar conexión y ejecución del runner, pero no conoce por sí solo la presión de disco, memoria, reinicios del contenedor o estado del daemon Docker interno.

## Logs

Logs estándar:

```bash
docker compose logs runner --tail=200
docker compose logs docker-ci --tail=200
docker compose logs -f
```

Los logs tienen rotación por tamaño configurada en `compose.yml`.

Logs internos del runner:

```bash
sudo ls -lah /srv/coferlandia-ci/runner/_diag
```

Los archivos `Runner_*.log` diagnostican listener y conectividad. Los `Worker_*.log` corresponden a jobs.

Logs de systemd:

```bash
journalctl -u coferlandia-ci-watchdog.service --since today
journalctl -u coferlandia-ci-cleanup.service --since today
systemctl list-timers 'coferlandia-ci-*' --all
```

## Configurar Telegram

### 1. Crear o reutilizar un bot

Use `@BotFather` en Telegram para crear un bot y obtener su token. Puede utilizar un bot existente siempre que el chat de alertas esté autorizado.

### 2. Obtener `chat_id`

Envíe `/start` al bot y ejecute:

```bash
./scripts/discover-telegram-chat-id.sh
```

Para un grupo, agregue el bot, envíe un mensaje y vuelva a ejecutar el script. Los IDs de grupos suelen ser negativos.

### 3. Guardar secretos

```bash
sudo nano /etc/coferlandia-ci-watchdog.env
```

Complete:

```env
TELEGRAM_BOT_TOKEN=123456789:token
TELEGRAM_CHAT_ID=123456789
```

Proteja el archivo:

```bash
sudo chown root:root /etc/coferlandia-ci-watchdog.env
sudo chmod 600 /etc/coferlandia-ci-watchdog.env
```

El token no se monta en el runner y no queda disponible para workflows.

### 4. Probar

```bash
sudo ./scripts/test-telegram.sh
sudo systemctl start coferlandia-ci-watchdog.service
```

## Consulta remota de GitHub

Opcionalmente complete:

```env
GITHUB_MONITOR_TOKEN=github_pat_...
GITHUB_SCOPE_TYPE=org
GITHUB_OWNER=coferlandia
GITHUB_REPOSITORY=
MONITORED_RUNNER_NAME=coferlandia-ci-01
```

Para alcance `repo`:

```env
GITHUB_SCOPE_TYPE=repo
GITHUB_OWNER=coferlandia
GITHUB_REPOSITORY=nombre-repositorio
```

Sin token, el watchdog sigue controlando toda la infraestructura local.

## Condiciones monitoreadas

- Docker del host no responde.
- Contenedor ausente o detenido.
- Healthcheck `unhealthy`.
- Docker CI no responde.
- Reinicios repetidos.
- Filesystem no montado.
- Disco del área CI por encima de umbrales.
- Filesystem raíz de la VM por encima de umbrales.
- Runner no encontrado u `offline` en GitHub, cuando la consulta está configurada.

## Deduplicación

El watchdog envía:

- una alerta al pasar de saludable a fallido;
- otra si cambia el conjunto de problemas;
- un recordatorio después del intervalo configurado;
- un mensaje de recuperación al volver a estar saludable.

No envía el mismo mensaje cada cinco minutos.

## Limitación de monitoreo local

Si toda la VM se apaga, pierde red o systemd deja de ejecutarse, el watchdog local tampoco puede alertar. Para cubrir ese escenario se necesita un monitor externo que espere un heartbeat o consulte la API de GitHub desde otra máquina.
