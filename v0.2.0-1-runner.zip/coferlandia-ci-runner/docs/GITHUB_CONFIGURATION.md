# Conexión con GitHub

## Alcance recomendado

Para varios repositorios de Coferlandia, registre el runner a nivel organización y restrinja el runner group a repositorios privados seleccionados.

Ruta general:

```text
GitHub organization
→ Settings
→ Actions
→ Runner groups
→ New runner group
```

Cree, por ejemplo, `trusted-ci`, seleccione únicamente repositorios confiables y cambie en `.env`:

```env
RUNNER_GROUP=trusted-ci
```

Luego:

```text
Settings
→ Actions
→ Runners
→ New self-hosted runner
```

No necesita copiar los comandos de descarga que muestra GitHub: este proyecto ya contiene el runner. Sí necesita copiar el token temporal de registro y entregarlo a:

```bash
./scripts/register-runner.sh
```

## Runner por repositorio

Para limitarlo a un solo repositorio:

```env
RUNNER_URL=https://github.com/OWNER/REPOSITORY
RUNNER_GROUP=Default
```

Obtenga el token en:

```text
Repository
→ Settings
→ Actions
→ Runners
→ New self-hosted runner
```

## Etiquetas

GitHub agrega automáticamente etiquetas como `self-hosted`, `linux` y la arquitectura. Este proyecto agrega:

```env
RUNNER_LABELS=coferlandia-ci,docker
```

Los jobs deben seleccionar el runner así:

```yaml
runs-on: [self-hosted, linux, coferlandia-ci]
```

Si usa runner group y la sintaxis de su organización lo permite:

```yaml
runs-on:
  group: trusted-ci
  labels: coferlandia-ci
```

## Permisos de workflows

Use permisos mínimos por defecto:

```yaml
permissions:
  contents: read
```

Amplíelos únicamente en jobs que realmente deban publicar, comentar, crear releases o desplegar.

## Ramas y pull requests

Este runner ejecuta código con capacidad de controlar el daemon Docker interno. No permita ejecución automática de código no confiable.

Recomendaciones:

- repositorios privados o mantenidos por el equipo;
- no ejecutar automáticamente PR provenientes de forks públicos;
- restringir runner groups a repositorios seleccionados;
- proteger ambientes y secrets productivos;
- separar CI de deployment;
- requerir revisión de workflows modificados.

## Monitoreo remoto opcional

El watchdog puede consultar el estado `online/offline/busy` de GitHub. Para una organización, un fine-grained token necesita permiso de organización `Self-hosted runners: read`. Para un runner de repositorio necesita `Administration: read` sobre ese repositorio.

Guarde el token solamente en:

```text
/etc/coferlandia-ci-watchdog.env
```

Nunca en `.env` ni como secret accesible al workflow.

## Actualización del runner

El runner oficial se actualiza automáticamente, pero también debe actualizarse periódicamente la imagen base:

```bash
./scripts/update.sh
```

Realice esta operación cuando el runner esté idle. Se recomienda revisar actualizaciones mensualmente y ante avisos de GitHub.
