# Instalación en la VM

Para conexión SSH, transferencia desde Git Bash y creación de carpetas, consulte primero [VM_DEPLOYMENT.md](VM_DEPLOYMENT.md).

## 1. Requisitos

Sistema recomendado:

- Ubuntu Server 22.04 o 24.04.
- Docker Engine funcionando.
- Docker Compose v2 (`docker compose`).
- Acceso SSH con un usuario que pueda ejecutar `sudo`.
- Arquitectura `x86_64` o `arm64/aarch64`.
- Espacio suficiente para el filesystem de CI. La configuración predeterminada limita CI a 30 GB.

Instale utilidades necesarias:

```bash
sudo apt update
sudo apt install -y   ca-certificates curl git jq unzip   util-linux e2fsprogs
```

Verifique Docker:

```bash
docker info
docker compose version
```

El usuario operativo debe poder usar Docker. Si se agrega al grupo `docker`, cierre sesión y vuelva a entrar:

```bash
sudo usermod -aG docker "$USER"
```

El grupo `docker` equivale prácticamente a acceso root sobre el host. Otórguelo sólo al administrador de la VM; los workflows no reciben el socket Docker del host.

## 2. Extraer el proyecto

Ejemplo bajo el usuario `ubuntu`:

```bash
mkdir -p /home/ubuntu/docker-projects
cd /home/ubuntu/docker-projects
unzip /home/ubuntu/uploads/coferlandia-ci-runner-0.2.0.zip
cd coferlandia-ci-runner
```

Antes de modificar la VM, genere el relevamiento inicial:

```bash
./scripts/host-survey.sh before
```

## 3. Crear la configuración

```bash
cp .env.example .env
nano .env
```

Ajuste como mínimo:

```env
RUNNER_URL=https://github.com/coferlandia
RUNNER_NAME=coferlandia-ci-01
RUNNER_LABELS=coferlandia-ci,docker
RUNNER_GROUP=Default
```

Puede registrar el runner para:

- una organización: `https://github.com/ORGANIZACION`;
- un repositorio: `https://github.com/OWNER/REPOSITORIO`.

Revise los límites según la VM:

```env
RUNNER_CPUS=0.75
RUNNER_MEMORY=1g
DIND_CPUS=2.0
DIND_MEMORY=4g
CI_STORAGE_SIZE=30G
```

Los límites son máximos, no reservas completas. Docker puede asignar menos CPU cuando el host está ocupado.

## 4. Crear el almacenamiento limitado

```bash
sudo ./scripts/install-host.sh
```

El script:

1. crea `/var/lib/coferlandia-ci.img` como archivo sparse del tamaño configurado;
2. crea un filesystem ext4 dentro del archivo;
3. lo monta en `/srv/coferlandia-ci` mediante loop device;
4. agrega una entrada `nofail` a `/etc/fstab`;
5. crea directorios y permisos para runner, workspace, cachés, certificados y Docker CI.

Compruebe:

```bash
findmnt /srv/coferlandia-ci
df -h /srv/coferlandia-ci
```

El archivo sparse no reserva inmediatamente los 30 GB, pero el filesystem interno no puede superar ese tamaño.

## 5. Comprobar prerrequisitos

```bash
./scripts/check-prerequisites.sh
```

## 6. Registrar en GitHub

Siga primero [GITHUB_CONFIGURATION.md](GITHUB_CONFIGURATION.md) para obtener el token temporal. Luego:

```bash
./scripts/register-runner.sh
```

El token se pasa únicamente a un contenedor temporal que registra el runner. No se escribe en `.env`, no queda en el contenedor persistente y vence rápidamente.

Al terminar:

```bash
./scripts/status.sh
```

## 7. Instalar mantenimiento y monitoreo

```bash
sudo ./scripts/install-systemd.sh
```

Esto instala:

- watchdog cada 5 minutos;
- cleanup diario alrededor de las 04:15;
- archivo privado `/etc/coferlandia-ci-watchdog.env`.

Configure Telegram y, opcionalmente, la API de GitHub siguiendo [MONITORING.md](MONITORING.md).

## 8. Verificar

```bash
./scripts/verify-installation.sh
./scripts/host-survey.sh after-idle
```

Compare ambos estados siguiendo [HOST_SURVEY.md](HOST_SURVEY.md).

Luego instale el workflow de prueba:

```bash
mkdir -p .github/workflows
cp examples/workflows/runner-smoke-test.yml   /ruta/al/repositorio/.github/workflows/
```

Commit, push y ejecútelo desde `Actions > Self-hosted runner smoke test > Run workflow`.

## 9. Arranque automático

Los contenedores usan `restart: unless-stopped`. Cuando Docker arranca tras un reboot, el stack registrado vuelve a iniciarse siempre que los contenedores ya hayan sido creados.

Compruebe después de reiniciar:

```bash
sudo reboot
# Al volver a entrar:
cd /home/ubuntu/docker-projects/coferlandia-ci-runner
./scripts/status.sh
systemctl list-timers 'coferlandia-ci-*' --all
```

## 10. Desinstalación

Primero elimine correctamente el runner en GitHub:

```bash
./scripts/unregister-runner.sh
```

Retire los timers:

```bash
sudo ./scripts/uninstall-systemd.sh
```

Para eliminar también el almacenamiento, sólo después de confirmar que no se necesita nada:

```bash
sudo umount /srv/coferlandia-ci
sudo sed -i '\|/var/lib/coferlandia-ci.img /srv/coferlandia-ci|d' /etc/fstab
sudo rm -f /var/lib/coferlandia-ci.img
sudo rmdir /srv/coferlandia-ci
```
