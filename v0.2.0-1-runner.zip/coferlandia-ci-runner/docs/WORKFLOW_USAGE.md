# Uso en workflows

## Selección del runner

```yaml
runs-on: [self-hosted, linux, coferlandia-ci]
```

## Configuración base

```yaml
name: CI

on:
  pull_request:
  push:
    branches: [main]

permissions:
  contents: read

concurrency:
  group: ci-${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true

jobs:
  test:
    runs-on: [self-hosted, linux, coferlandia-ci]
    timeout-minutes: 30

    steps:
      - uses: actions/checkout@v6
        with:
          clean: true

      - run: ./scripts/test.sh
```

`clean: true` evita que archivos generados por una ejecución anterior alteren el checkout. El directorio físico puede persistir, pero Git queda en el commit correcto.

## Proyectos con Docker Compose

Use un nombre exclusivo por ejecución:

```yaml
env:
  COMPOSE_PROJECT_NAME: ci-${{ github.run_id }}-${{ github.run_attempt }}
```

Y cierre siempre:

```yaml
- name: Tests
  run: docker compose up --build --abort-on-container-exit --exit-code-from tests

- name: Cleanup
  if: always()
  run: docker compose down --volumes --remove-orphans
```

## Cachés

Las cachés locales persistentes ya están configuradas:

- `NUGET_PACKAGES=/cache/nuget`;
- `npm_config_cache=/cache/npm`;
- `PIP_CACHE_DIR=/cache/pip`;
- `RUNNER_TOOL_CACHE=/cache/toolcache`.

No es obligatorio usar `actions/cache` para obtener reutilización local. Evitarlo también reduce almacenamiento de artifacts/caches en GitHub.

## Artifacts

Como el objetivo es validación previa al merge y no conservar resultados, no use `actions/upload-artifact` por defecto. Agréguelo sólo para diagnósticos concretos y con retención corta.

## Timeouts y concurrencia

Todos los jobs deberían tener `timeout-minutes`. Con un solo runner, la concurrencia real es uno, pero `cancel-in-progress` evita gastar recursos en commits superados de la misma rama.

## Toolchains

Puede usar `actions/setup-dotnet`, `actions/setup-node`, `actions/setup-python` y acciones equivalentes. La tool cache persistente acelera instalaciones siguientes, pero la limpieza por presión de disco puede descartarlas.

## Limitación conceptual

GitHub Actions sólo ejecuta código que GitHub conoce: commit, branch o pull request. Los cambios únicamente presentes y sin commit en un worktree local no llegan al runner.
