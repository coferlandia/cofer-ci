# Changelog

## 0.2.0 - 2026-08-02

- Guía completa para conexión SSH desde Windows/Git Bash.
- Transferencia del ZIP y checksum mediante `scp`.
- Convención de carpetas independientes bajo `~/docker-projects`.
- Instrucciones explícitas para no publicar puertos del runner.
- Relevamiento automatizado de la VM antes, durante y después de instalar CI.
- Informes humanos y métricas comparables de CPU, memoria, discos, Docker, procesos y puertos.
- Script para comparar dos relevamientos y cuantificar el impacto del runner.
- Procedimiento para descargar los reportes nuevamente a Windows.

## 0.1.0 - 2026-08-02

- Primera versión instalable.
- Runner oficial de GitHub dentro de un contenedor sin privilegios.
- Docker-in-Docker exclusivo para CI con TLS interno.
- Límites de CPU, RAM, PIDs, logs y filesystem.
- Workspace y cachés persistentes para acelerar reintentos.
- Limpieza liviana por job y limpieza escalonada diaria.
- Watchdog por systemd con alertas Telegram y recuperación.
- Consulta remota opcional del estado del runner en GitHub.
- Documentación completa de instalación, red, operación y seguridad.
