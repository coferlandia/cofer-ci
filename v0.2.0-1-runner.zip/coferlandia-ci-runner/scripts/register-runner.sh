#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "${SCRIPT_DIR}/common.sh"

load_env
require_command docker

[[ -d "${CI_STORAGE_ROOT}" ]] || fatal "No existe ${CI_STORAGE_ROOT}; ejecute sudo scripts/install-host.sh"
mountpoint -q "${CI_STORAGE_ROOT}" || fatal "${CI_STORAGE_ROOT} no está montado"

if [[ -f "${CI_STORAGE_ROOT}/runner/.runner" ]]; then
  fatal "Ya existe un registro local. Use scripts/status.sh o desregistre primero."
fi

cat <<EOF
Obtenga un token temporal desde GitHub:
  Settings > Actions > Runners > New self-hosted runner

URL configurada: ${RUNNER_URL}
Nombre:          ${RUNNER_NAME}
Etiquetas:       ${RUNNER_LABELS}
Grupo:           ${RUNNER_GROUP}
EOF

read -r -s -p "Token temporal de registro: " RUNNER_TOKEN
printf '\n'
[[ -n "$RUNNER_TOKEN" ]] || fatal "El token no puede estar vacío"

log "Construyendo la imagen del runner"
compose build --pull runner

log "Iniciando Docker CI para generar certificados TLS"
compose up -d docker-ci

log "Esperando que Docker CI esté saludable"
for _ in $(seq 1 60); do
  dind_cid="$(compose ps -q docker-ci 2>/dev/null || true)"
  status=""
  if [[ -n "$dind_cid" ]]; then
    status="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{end}}' "$dind_cid" 2>/dev/null || true)"
  fi
  [[ "$status" == "healthy" ]] && break
  sleep 2
done

[[ "$status" == "healthy" ]] || fatal "Docker CI no alcanzó estado healthy. Revise: docker compose logs docker-ci"

log "Registrando runner mediante un contenedor de un solo uso"
RUNNER_TOKEN="$RUNNER_TOKEN" compose run --rm --no-deps \
  -e RUNNER_TOKEN="$RUNNER_TOKEN" \
  runner register
unset RUNNER_TOKEN

log "Iniciando el runner persistente"
compose up -d runner

log "Registro terminado"
"${SCRIPT_DIR}/status.sh" || true
