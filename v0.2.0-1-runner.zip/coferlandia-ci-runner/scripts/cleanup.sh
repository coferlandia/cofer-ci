#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "${SCRIPT_DIR}/common.sh"

load_env

require_command docker
mountpoint -q "${CI_STORAGE_ROOT}" || fatal "${CI_STORAGE_ROOT} no está montado"

usage_before="$(storage_usage_percent)"
busy=false
runner_is_busy && busy=true

log "Limpieza iniciada. Uso=${usage_before}% busy=${busy}"

# Sólo elimina imágenes antiguas de este proyecto en el Docker del host.
# No ejecuta una poda global que pueda afectar al stack productivo.
docker image prune -af \
  --filter 'label=io.coferlandia.ci=true' \
  --filter "until=${IMAGE_RETENTION_HOURS:-168}h" >/dev/null 2>&1 || true

# Estas operaciones son seguras durante un job: sólo afectan recursos no usados.
compose exec -T docker-ci docker container prune -f >/dev/null 2>&1 || true
compose exec -T docker-ci docker network prune -f >/dev/null 2>&1 || true
compose exec -T docker-ci docker volume prune -f >/dev/null 2>&1 || true
compose exec -T docker-ci docker image prune -af \
  --filter "until=${IMAGE_RETENTION_HOURS:-168}h" >/dev/null 2>&1 || true
compose exec -T docker-ci docker builder prune -af \
  --keep-storage "${BUILDKIT_CACHE_KEEP:-6GB}" >/dev/null 2>&1 || true
compose exec -T docker-ci docker buildx prune -af \
  --max-used-space "${BUILDKIT_CACHE_KEEP:-6GB}" >/dev/null 2>&1 || true

if [[ "$busy" == false ]]; then
  find "${CI_STORAGE_ROOT}/cache" -type f \
    -mtime "+${PACKAGE_CACHE_RETENTION_DAYS:-30}" -delete 2>/dev/null || true
fi

usage="$(storage_usage_percent)"

if (( usage >= ${DISK_AGGRESSIVE_PERCENT:-82} )) && [[ "$busy" == false ]]; then
  log "Umbral agresivo alcanzado (${usage}%). Reduciendo cachés y workspaces antiguos."
  compose exec -T docker-ci docker image prune -af --filter 'until=24h' >/dev/null 2>&1 || true
  compose exec -T docker-ci docker builder prune -af \
    --keep-storage "${BUILDKIT_CACHE_EMERGENCY_KEEP:-1GB}" >/dev/null 2>&1 || true
  compose exec -T docker-ci docker buildx prune -af \
    --max-used-space "${BUILDKIT_CACHE_EMERGENCY_KEEP:-1GB}" >/dev/null 2>&1 || true

  find "${CI_STORAGE_ROOT}/work" \
    -mindepth 1 -maxdepth 1 \
    ! -name '_actions' ! -name '_tool' ! -name '_temp' \
    -mtime "+${WORKSPACE_RETENTION_DAYS:-7}" \
    -exec rm -rf -- {} + 2>/dev/null || true

  find "${CI_STORAGE_ROOT}/cache" -type f -mtime +7 -delete 2>/dev/null || true
fi

usage="$(storage_usage_percent)"
marker="${CI_STORAGE_ROOT}/.runner-paused-disk"

if (( usage >= ${DISK_EMERGENCY_PERCENT:-90} )) && [[ "$busy" == false ]]; then
  warn "Umbral de emergencia alcanzado (${usage}%). Se detiene el runner para proteger la VM."
  compose stop runner >/dev/null 2>&1 || true
  touch "$marker"
elif [[ -f "$marker" ]] && (( usage <= ${DISK_RECOVERY_PERCENT:-70} )); then
  log "El almacenamiento volvió a ${usage}%. Reiniciando runner pausado."
  compose up -d runner >/dev/null
  rm -f "$marker"
fi

usage_after="$(storage_usage_percent)"
log "Limpieza terminada. Uso antes=${usage_before}% después=${usage_after}%"
compose exec -T docker-ci docker system df 2>/dev/null || true
