#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "${SCRIPT_DIR}/common.sh"

load_env

if [[ ! -f "${CI_STORAGE_ROOT}/runner/.runner" ]]; then
  log "No existe registro local"
  exit 0
fi

cat <<EOF
Obtenga un token de eliminación desde la pantalla del runner en GitHub.
El token de registro inicial no necesariamente sirve para eliminarlo.
EOF
read -r -s -p "Token temporal de eliminación: " RUNNER_TOKEN
printf '\n'
[[ -n "$RUNNER_TOKEN" ]] || fatal "El token no puede estar vacío"

compose stop runner || true
RUNNER_TOKEN="$RUNNER_TOKEN" compose run --rm --no-deps \
  -e RUNNER_TOKEN="$RUNNER_TOKEN" \
  runner remove
unset RUNNER_TOKEN

log "Runner desregistrado. Docker CI permanece instalado pero detenido."
compose down
