#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/common.sh"
load_env

failures=0
check() {
  local description="$1"
  shift
  if "$@"; then
    printf 'OK    %s\n' "$description"
  else
    printf 'ERROR %s\n' "$description"
    failures=$((failures + 1))
  fi
}

check "Docker host responde" docker info
check "Filesystem CI montado" mountpoint -q "$CI_STORAGE_ROOT"
check "Runner registrado localmente" test -f "$CI_STORAGE_ROOT/runner/.runner"
check "Contenedor runner healthy" bash -c 'cid=$(docker compose --project-directory "$0" --env-file "$0/.env" ps -q runner); test -n "$cid" && test "$(docker inspect -f "{{.State.Health.Status}}" "$cid")" = healthy' "$PROJECT_DIR"
check "Docker CI responde" compose exec -T docker-ci docker info
check "Docker Compose dentro del runner" compose exec -T runner docker compose version
check "Salida HTTPS hacia GitHub" compose exec -T runner curl -fsS --max-time 15 https://api.github.com/zen
check "Salida HTTPS hacia Telegram" curl -sS -o /dev/null --max-time 15 https://api.telegram.org

if (( failures > 0 )); then
  printf '\nFallaron %s comprobaciones.\n' "$failures"
  exit 1
fi

printf '\nInstalación local verificada. Ejecute también el workflow smoke test.\n'
