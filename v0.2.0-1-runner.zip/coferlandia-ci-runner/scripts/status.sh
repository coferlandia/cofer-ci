#!/usr/bin/env bash
set -uo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=common.sh
source "${SCRIPT_DIR}/common.sh"

load_env
load_monitor_env

printf 'Coferlandia CI Runner\n\n'

if ! docker info >/dev/null 2>&1; then
  printf 'Docker host:             ERROR - no responde\n'
  exit 1
fi
printf 'Docker host:             OK\n'

compose ps || true
printf '\n'

runner_cid="$(compose ps -q runner 2>/dev/null || true)"
dind_cid="$(compose ps -q docker-ci 2>/dev/null || true)"

for pair in "runner:${runner_cid}" "docker-ci:${dind_cid}"; do
  service="${pair%%:*}"
  cid="${pair#*:}"
  if [[ -z "$cid" ]]; then
    printf '%-24s %s\n' "${service}:" "missing"
    continue
  fi
  state="$(docker inspect -f '{{.State.Status}}' "$cid" 2>/dev/null || echo unknown)"
  health="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}n/a{{end}}' "$cid" 2>/dev/null || echo unknown)"
  restarts="$(docker inspect -f '{{.RestartCount}}' "$cid" 2>/dev/null || echo '?')"
  printf '%-24s state=%s health=%s restarts=%s\n' "${service}:" "$state" "$health" "$restarts"
done

if [[ -n "$dind_cid" ]] && compose exec -T docker-ci docker info >/dev/null 2>&1; then
  printf '%-24s %s\n' 'Docker CI:' 'OK'
else
  printf '%-24s %s\n' 'Docker CI:' 'ERROR'
fi

if mountpoint -q "${CI_STORAGE_ROOT}"; then
  usage="$(storage_usage_percent)"
  printf '%-24s %s%% usado\n' 'Filesystem CI:' "$usage"
  df -h "${CI_STORAGE_ROOT}" | tail -n 1
else
  printf '%-24s %s\n' 'Filesystem CI:' 'NO MONTADO'
fi

printf '\nRecursos actuales:\n'
if [[ -n "$runner_cid$dind_cid" ]]; then
  docker stats --no-stream --format 'table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.PIDs}}' \
    $runner_cid $dind_cid 2>/dev/null || true
fi

printf '\nUso interno de Docker CI:\n'
compose exec -T docker-ci docker system df 2>/dev/null || true

if [[ -n "${GITHUB_MONITOR_TOKEN:-}" ]]; then
  if [[ "${GITHUB_SCOPE_TYPE:-org}" == "repo" ]]; then
    api="https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPOSITORY}/actions/runners?per_page=100&name=${MONITORED_RUNNER_NAME:-$RUNNER_NAME}"
  else
    api="https://api.github.com/orgs/${GITHUB_OWNER}/actions/runners?per_page=100&name=${MONITORED_RUNNER_NAME:-$RUNNER_NAME}"
  fi

  response="$(curl -fsS \
    -H 'Accept: application/vnd.github+json' \
    -H "Authorization: Bearer ${GITHUB_MONITOR_TOKEN}" \
    -H "X-GitHub-Api-Version: ${GITHUB_API_VERSION:-2026-03-10}" \
    "$api" 2>/dev/null || true)"
  remote="$(jq -r --arg name "${MONITORED_RUNNER_NAME:-$RUNNER_NAME}" '.runners[]? | select(.name == $name) | "status=" + .status + " busy=" + (.busy|tostring) + " version=" + (.version // "n/a")' <<<"$response" | head -n1)"
  printf '\n%-24s %s\n' 'GitHub runner:' "${remote:-no encontrado}"
else
  printf '\nGitHub runner:           consulta remota no configurada\n'
fi
