#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/common.sh"
load_env

runner_is_busy && fatal "Hay un job en ejecución. Actualice cuando el runner esté idle."

log "Descargando imagen Docker-in-Docker y reconstruyendo desde el runner oficial"
compose pull docker-ci
compose build --pull --no-cache runner
compose up -d
"${SCRIPT_DIR}/status.sh"
