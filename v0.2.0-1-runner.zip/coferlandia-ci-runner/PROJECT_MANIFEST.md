# Project manifest

Version: 0.2.0

## Runtime

- `compose.yml`: runner y Docker-in-Docker aislado, sin puertos publicados.
- `runner/`: imagen derivada del runner oficial y ciclo register/run/remove.
- `hooks/`: limpieza liviana antes y después de cada job.
- `config/docker-daemon.json`: BuildKit, garbage collection y rotación de logs.

## Host lifecycle

- `scripts/install-host.sh`: filesystem ext4 limitado mediante archivo loopback.
- `scripts/register-runner.sh`: registro con token temporal no persistente.
- `scripts/status.sh`: estado local, recursos, disco y estado remoto opcional.
- `scripts/cleanup.sh`: limpieza escalonada y pausa por presión de disco.
- `scripts/watchdog.sh`: diagnósticos, deduplicación y alertas Telegram.
- `scripts/host-survey.sh`: relevamiento de sistema, recursos, Docker, procesos y puertos.
- `scripts/compare-host-surveys.sh`: comparación cuantitativa de relevamientos.
- `systemd/`: timers de watchdog y mantenimiento.

## Documentation

- conexión SSH desde Windows/Git Bash;
- transferencia y verificación del ZIP;
- estructura de carpetas del proyecto independiente;
- instalación completa;
- relevamiento antes, durante y después;
- conexión y permisos de GitHub;
- redes y ausencia de puertos publicados;
- mantenimiento, limpieza y actualización;
- monitoreo, logs y Telegram;
- seguridad, workflows y troubleshooting.

## Validation performed

- sintaxis Bash de todos los scripts;
- parseo YAML de Compose y workflows de ejemplo;
- parseo JSON de la configuración Docker;
- verificación de enlaces Markdown relativos;
- comprobación de ausencia de `.env` y secretos reales en el paquete;
- generación de un relevamiento de prueba sin Docker disponible.

La construcción y ejecución real de Docker debe verificarse en la VM objetivo,
ya que el entorno de empaquetado no dispone de Docker Engine.
